package com.flip.assignment.entity.constant;

public class CommonConstant {

    public static final String DEBIT = "DEBIT";
    public static final String CREDIT = "CREDIT";
    public static final String TOPUP = "TOPUP";
    public static final String REDIS_KEY = "flip-assignment";
    public static final String AUTHORIZED_HEADER = "Authorization";
}
