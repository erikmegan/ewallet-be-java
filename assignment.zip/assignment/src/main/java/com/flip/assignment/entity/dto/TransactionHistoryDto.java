package com.flip.assignment.entity.dto;

import java.math.BigDecimal;



public interface TransactionHistoryDto {

    public String getUsername();
    public BigDecimal getTransactedValue();



}
