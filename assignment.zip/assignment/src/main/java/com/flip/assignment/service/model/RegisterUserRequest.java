package com.flip.assignment.service.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RegisterUserRequest {

    private String username;

}
