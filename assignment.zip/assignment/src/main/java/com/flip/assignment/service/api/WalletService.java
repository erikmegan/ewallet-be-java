package com.flip.assignment.service.api;

import com.flip.assignment.service.model.WalletResponse;

public interface WalletService {

    public WalletResponse getWalletUser();
}
